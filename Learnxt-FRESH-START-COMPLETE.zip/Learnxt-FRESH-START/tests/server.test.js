import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer,generateDeck,validateInput,extractSourcesFromResearch,getProviderStatus} from '../server.js';

const material={provider:'groq',mode:'topic',input:'Total internal reflection',count:5,difficulty:'Balanced',goal:'Ace my exam',search:false};
const cards={title:'Optical Fibres',summary:'Concepts for exams',cards:Array.from({length:5},(_,i)=>({question:`Q${i+1}?`,answer:`A${i+1}`,explanation:'Learn the physics.',example:'In a fibre.',memoryTip:'Remember the rule.',tag:'Physics'}))};
const env={GROQ_API_KEY:'gsk_validtest123',GROQ_MODEL:'openai/gpt-oss-20b',GEMINI_API_KEY:'AIza_fakebutconfigured123',GEMINI_MODEL:'gemini-2.5-flash',OPENAI_API_KEY:'sk_fakebutconfigured123',OPENAI_MODEL:'gpt-4.1-mini'};
function mockFetch(log) {return async(url,opts)=>{
  const body=JSON.parse(opts.body);log.push({url,headers:opts.headers,body});
  const isResearch=!!(body.tools?.length);
  if(url.includes('generativelanguage')) return new Response(JSON.stringify({candidates:[{content:{parts:[{text:isResearch?'Verified claim; reference via grounding.':JSON.stringify(cards)}]},groundingMetadata:{groundingChunks:[{web:{uri:'https://science.nasa.gov/',title:'NASA Science'}}]}}]}),{status:200});
  if(url.includes('api.openai.com'))return new Response(JSON.stringify({output:[{type:'message',content:[{type:'output_text',text:isResearch?'Reliable source on https://science.nasa.gov/':JSON.stringify(cards),annotations:isResearch?[{type:'url_citation',url:'https://science.nasa.gov/',title:'NASA Science'}]:[]}]}]}),{status:200});
  return new Response(JSON.stringify({choices:[{message:{content:isResearch?'Study notes based on https://science.nasa.gov/':JSON.stringify(cards)}}]}),{status:200});
};}
test('input and provider validation',()=>{
  assert.equal(validateInput(material).provider,'groq');
  assert.equal(validateInput({...material,provider:'gemini'}).provider,'gemini');
  assert.throws(()=>validateInput({...material,provider:'other'}),/valid AI provider/);
  assert.throws(()=>validateInput({...material,count:30}),/5 to 24/);
  assert.throws(()=>validateInput({...material,mode:'file',input:'',pdfText:'abc'}),/No readable PDF/);
  assert.equal(validateInput({...material,mode:'file',input:'',pdfText:'z'.repeat(55)}).pdfText.length,55);
});
test('API status never exposes provider credentials',()=>{
  const status=getProviderStatus(env);
  assert.equal(status.length,3);
  assert.equal(status.filter(p=>p.configured).length,3);
  assert.equal(status.find(p=>p.id==='groq').model,'openai/gpt-oss-20b');
  assert.ok(!JSON.stringify(status).includes('gsk_validtest'));
});
test('Groq creates cards using strict JSON schema',async()=>{
  const calls=[];const out=await generateDeck(material,{env,fetchImpl:mockFetch(calls)});
  assert.equal(calls.length,1);
  assert.match(calls[0].url,/groq.com\/openai\/v1\/chat\/completions/);
  assert.equal(calls[0].headers.Authorization,'Bearer gsk_validtest123');
  assert.equal(calls[0].body.response_format.type,'json_schema');
  assert.equal(out.deck.provider,'Groq');assert.equal(out.deck.cards.length,5);
  assert.equal(out.deck.verified,false);assert.equal(out.deck.searchStatus,'off');
});
test('Groq research uses browser_search separate from JSON schema',async()=>{
  const calls=[];const out=await generateDeck({...material,search:true},{env,fetchImpl:mockFetch(calls)});
  assert.equal(calls.length,2);assert.equal(calls[0].body.tools[0].type,'browser_search');
  assert.equal(calls[0].body.response_format,undefined);
  assert.equal(out.deck.sources[0].url,'https://science.nasa.gov/');
});
test('Gemini research and structured generation use correct endpoint',async()=>{
  const calls=[];const out=await generateDeck({...material,provider:'gemini',search:true},{env,fetchImpl:mockFetch(calls)});
  assert.equal(calls.length,2);assert.match(calls[0].url,/generativelanguage.googleapis.com/);
  assert.deepEqual(calls[0].body.tools,[{googleSearch:{}}]);
  assert.equal(calls[1].body.generationConfig.responseMimeType,'application/json');
  assert.equal(out.deck.provider,'Google Gemini');assert.equal(out.deck.sources[0].title,'NASA Science');
  assert.equal(out.deck.cards.length,5);
});
test('OpenAI Responses API research, annotations, structured generation',async()=>{
  const calls=[];const out=await generateDeck({...material,provider:'openai',search:true},{env,fetchImpl:mockFetch(calls)});
  assert.equal(calls.length,2);assert.equal(calls[0].url,'https://api.openai.com/v1/responses');
  assert.deepEqual(calls[0].body.tools,[{type:'web_search'}]);
  assert.equal(calls[1].body.text.format.type,'json_schema');
  assert.equal(calls[1].body.store,false);assert.equal(out.deck.provider,'OpenAI');
  assert.equal(out.deck.sources[0].url,'https://science.nasa.gov/');
});
test('missing key only affects selected provider',async()=>{
  await assert.rejects(()=>generateDeck({...material,provider:'openai'},{env:{GROQ_API_KEY:'gsk_123456789'},fetchImpl:mockFetch([])}),e=>e.status===503&&/OPENAI_API_KEY/.test(e.message));
  assert.equal((await generateDeck(material,{env,fetchImpl:mockFetch([])})).deck.provider,'Groq');
});
test('rate limits and denied keys return helpful messages without secrets',async()=>{
  const failure=async()=>new Response(JSON.stringify({error:{message:'echo key gsk_VALIDSECRETHERE'}}),{status:401});
  await assert.rejects(()=>generateDeck(material,{env,fetchImpl:failure}),e=>e.status===401&&!e.message.includes('gsk_VALIDSECRETHERE'));
  const failure429=async()=>new Response('{}',{status:429});
  await assert.rejects(()=>generateDeck(material,{env,fetchImpl:failure429}),e=>e.status===429&&/limit/i.test(e.message));
});
test('research URL parser ignores made-up citation tokens and duplicate URLs',()=>{
  assert.deepEqual(extractSourcesFromResearch('https://example.edu/path https://example.edu/path. 〖citation〗'),[{title:'example.edu',url:'https://example.edu/path'}]);
});
test('local website routes /api/status and protects private files',async()=>{
  const server=createServer({env});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const url=`http://127.0.0.1:${server.address().port}`;
  try {
    const info=await (await fetch(url+'/api/status')).json();
    assert.equal(info.providers.length,3);assert.equal(info.connected,true);
    assert.ok(!JSON.stringify(info).includes('gsk_validtest123'));
    assert.match(await (await fetch(url)).text(),/Learnxt/);
    assert.equal((await fetch(url+'/server.js')).status,404);
    assert.equal((await fetch(url+'/.env')).status,404);
    assert.equal((await fetch(url+'/api/secret')).status,404);
  }finally{await new Promise(resolve=>server.close(resolve));}
});

test('Groq shows a safe, specific 400 error instead of a vague message', async()=>{
  const invalidModel=async()=>new Response(JSON.stringify({error:{message:'The model `wrong-model` does not exist (api key gsk_123456789secret).'}}),{status:400});
  await assert.rejects(()=>generateDeck(material,{env,fetchImpl:invalidModel}),e=>e.status===400 && /wrong-model/.test(e.message) && !e.message.includes('gsk_123456789secret'));
});

test('Groq retries JSON schema incompatibility with JSON object mode',async()=>{
  const calls=[];
  const mocked=async(_url,opts)=>{
    const body=JSON.parse(opts.body); calls.push(body);
    if(body.response_format.type==='json_schema') return new Response(JSON.stringify({error:{message:'response_format json_schema is not supported for this request'}}),{status:400});
    return new Response(JSON.stringify({choices:[{message:{content:JSON.stringify(cards)}}]}),{status:200});
  };
  const output=await generateDeck(material,{env,fetchImpl:mocked});
  assert.equal(calls.length,2);
  assert.equal(calls[0].response_format.type,'json_schema');
  assert.equal(calls[1].response_format.type,'json_object');
  assert.equal(output.deck.cards.length,5);
});
